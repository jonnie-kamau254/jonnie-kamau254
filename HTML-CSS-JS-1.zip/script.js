//giving the header a background hover color//
document.getElementById('header').addEventListener('mouseenter', function() {
  this.style.backgroundColor = '#ddd';
});
document.getElementById('header').addEventListener('mouseleave', function() {
  this.style.backgroundColor = 'transparent';
});

//gallery

  document.addEventListener("DOMContentLoaded", function () {
    const images = document.querySelectorAll('.slider img');
    const thumbnails = document.querySelectorAll('.thumbnails img');
    const lightbox = document.querySelector('.lightbox');
    const lightboxImage = document.getElementById('lightbox-image');
    let currentIndex = 0;

    function showImage(index) {
      images.forEach(img => img.style.display = 'none');
      images[index].style.display = 'none';

      thumbnails.forEach(thumb => thumb.classList.remove('active'));
      thumbnails[index].classList.add('active');
    }

    function nextSlide() {
      currentIndex = (currentIndex + 1) % images.length;
      showImage(currentIndex);
    }

    function selectSlide(index) {
      currentIndex = index;
      showImage(currentIndex);
    }

    // Show the first image initially
    showImage(currentIndex);

    // Automatically change slide every 10 seconds
    setInterval(nextSlide, 10000);

    // Thumbnail click event
    thumbnails.forEach((thumb, index) => {
      thumb.addEventListener('click', () => {
        selectSlide(index);
        openLightbox(images[index].src);
      });
    });

    // Lightbox functions
    function openLightbox(imageSrc) {
      lightboxImage.src = imageSrc;
      lightbox.style.display = 'flex';
    }

    lightbox.addEventListener('click', () => {
      lightbox.style.display = 'none';
    });
  });


//confirming phone link
   const phone = document.getElementById('phone');
phone.addEventListener('click', () => {
  console.log('phone link clicked');
});
phone.addEventListener('click', function(event) {
  event.preventDefault();
  const confirmation = confirm('Are you sure you want to contact jonnie kamau💁💁?');
  if (confirmation) {
    window.location.href = phone;
  }
});

//email link confarming
  const email = document.getElementById('email');
email.addEventListener('click', () => {
  console.log('email link clicked');
});
email.addEventListener('click', function(event) {
  event.preventDefault();
  const confirmation = confirm('Are you sure you want to contact jonnie kamau💁💁?');
  if (confirmation) {
    window.location.href = email;
  }
});

//project link
 const project = document.getElementById('project');
  project.addEventListener('click', () => {
  console.log('project link clicked');
});
  project.addEventListener('click', function(event) {
  event.preventDefault();
  const confirmation = confirm('Are you sure you want to leave this page💁💁?');
  if (confirmation) {
    window.location.href = project;
  }
});
//social media links
   const facebook = document.getElementById('facebook');
facebook.addEventListener('click', () => {
  console.log('Facebook link clicked');
});
facebook.addEventListener('click', function(event) {
  event.preventDefault();
  const confirmation = confirm('Are you sure you want to visit our Facebook page?');
  if (confirmation) {
    window.location.href = facebook;
  }
});

const IG = document.getElementById("IG");
IG.addEventListener('click', () => {
  console.log('Instagram link clicked');
});
IG.addEventListener('click', function(event) {
  event.preventDefault();
  const confirmation = confirm('Are you sure you want to visit our Instagram page?');
  if (confirmation) {
    window.location.href = IG;
  }
});
const linkedin = document.getElementById("linkedin");
linkedin.addEventListener('click', () => {
  console.log('linkedin link clicked');
});
linkedin.addEventListener('click', function(event) {
  event.preventDefault();
  const confirmation = confirm('Are you sure you want to visit our linkedin page?');
  if (confirmation) {
    window.location.href =linkedin;
  }
});

